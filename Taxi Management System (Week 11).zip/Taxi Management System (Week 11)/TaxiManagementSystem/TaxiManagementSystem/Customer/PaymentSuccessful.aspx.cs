﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TaxiManagementSystem.Customer
{
    public partial class PaymentSuccessful : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            


            DateTime bookingDate = Convert.ToDateTime((string)Session["bookingdate"]);
            DateTime bookingTime = Convert.ToDateTime((string)Session["bookingtime"]);

            SqlConnection sqlConn;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            sqlConn = new SqlConnection(connStr);
            sqlConn.Open();

            SqlCommand cmdAdd;
            string strAdd = "Insert into Booking(BookingID, BookingDate, DriverID, CustomerID, RouteID, BookingTime) Values (@BookingID, @BookingDate, @DriverID, @CustomerID, @RouteID, @BookingTime)";
            cmdAdd = new SqlCommand(strAdd, sqlConn);

            cmdAdd.Parameters.AddWithValue("@BookingID", (string)Session["bookingid"]);
            cmdAdd.Parameters.AddWithValue("@BookingDate", bookingDate);
            cmdAdd.Parameters.AddWithValue("@DriverID", (string)Session["driverid"]);
            cmdAdd.Parameters.AddWithValue("@CustomerID", (string)Session["custid"]);
            cmdAdd.Parameters.AddWithValue("@RouteID",(string)Session["routeid"]);
            cmdAdd.Parameters.AddWithValue("@BookingTime", bookingTime);

            int n = cmdAdd.ExecuteNonQuery();
            if (n < 1)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your booking has not been made!')", true);
            }

            //update driver status
            string strUpdateDriver = "Update Driver SET DriverStatus=@DriverStatus WHERE DriverID=@DriverID";
            SqlCommand cmdUpdateDriver;
            cmdUpdateDriver = new SqlCommand(strUpdateDriver, sqlConn);

            cmdUpdateDriver.Parameters.AddWithValue("@DriverStatus", "Busy");
            cmdUpdateDriver.Parameters.AddWithValue("@DriverID", (string)Session["driverid"]);

            int intUpdateDriverStatus = cmdUpdateDriver.ExecuteNonQuery();

            sqlConn.Close(); 



            string PaymentID = getNewPaymentID();

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            conn.Open();

            SqlCommand cmd = new SqlCommand("Insert Into Payment(PaymentID, PaymentDate, TotalCharges, BookingID) Values(@paymentid, @paymentdate, @totalcharges, @bookingid)", conn);
            cmd.Parameters.AddWithValue("@paymentid", PaymentID);
            cmd.Parameters.AddWithValue("@paymentdate", DateTime.Now);
            cmd.Parameters.AddWithValue("@totalcharges", Session["totalcharges"].ToString()); //pass totalcharges session from booking module
            cmd.Parameters.AddWithValue("@bookingid", Session["bookingid"].ToString()); //pass bookingid session from booking module

            int result = cmd.ExecuteNonQuery();

            if(result < 1){
                Page.ClientScript.RegisterStartupScript(this.GetType(),"ErrorAlert","alert('Record insertion failed.');",true);
            }

            conn.Close();
        }

        private string getNewPaymentID()
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            conn.Open();

            SqlCommand cmdID = new SqlCommand("Select PaymentID From Payment Order By PaymentID", conn);

            SqlDataReader dtr = cmdID.ExecuteReader();

            string lastID = "";

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    lastID = dtr["PaymentID"].ToString();
                }
            }

            char[] IDarr = lastID.ToCharArray();

            IDarr[4]++;
            if (IDarr[4] == ':')
            {
                IDarr[3]++;
                IDarr[4] = '0';
            }
            if (IDarr[3] == ':')
            {
                IDarr[2]++;
                IDarr[3] = '0';
            }
            if (IDarr[2] == ':')
            {
                IDarr[1]++;
                IDarr[2] = '0';
            }

            string newPaymentID = new String(IDarr);

            return newPaymentID;
        }
    }
}