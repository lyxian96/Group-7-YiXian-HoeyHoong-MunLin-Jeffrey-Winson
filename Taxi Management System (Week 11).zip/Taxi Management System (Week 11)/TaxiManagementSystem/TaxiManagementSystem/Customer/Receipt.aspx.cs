﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TaxiManagementSystem.Customer
{
    public partial class Receipt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            conn.Open();

            SqlCommand cmd = new SqlCommand("Select PaymentID, PaymentDate, CustomerName, BookingDate, CONVERT(varchar(15), CAST(BookingTime AS TIME), 100) AS 'BookingTime', PickUpAddress, Destination, TotalCharges " +
                                            "From Payment, Customer, Booking, Route " +
                                            "Where Customer.CustomerID=Booking.CustomerID And Route.RouteID=Booking.RouteID And Booking.BookingID=Payment.BookingID And Booking.BookingID = @bookingid", conn);
            cmd.Parameters.AddWithValue("@bookingid", Session["bookingid"].ToString());

            SqlDataReader dtr = cmd.ExecuteReader();

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    lblPaymentID.Text = dtr["PaymentID"].ToString();
                    lblPaymentDate.Text = dtr["PaymentDate"].ToString();
                    lblCustomerName.Text = dtr["CustomerName"].ToString();
                    lblDate.Text = ((DateTime)dtr["BookingDate"]).ToString("dd/MM/yyyy");
                    lblTime.Text = dtr["BookingTime"].ToString();
                    lblFrom.Text = dtr["PickUpAddress"].ToString();
                    lblTo.Text = dtr["Destination"].ToString();
                    lblTotalCharges.Text = dtr["TotalCharges"].ToString();
                }
            }

            dtr.Close();
            conn.Close();

        }
    }
}