﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TaxiManagementSystem.Customer
{
    public partial class PendingTrip : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session.Remove("bookingid");
            Session["bookingid"] = GridView1.SelectedValue.ToString();
        }

        protected void btnReceipt_Click(object sender, EventArgs e)
        {
            Response.Redirect("Receipt.aspx");
        }
    }
}