﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookingReservation
{
    public partial class favLocation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblcustuserName.Text = (string)Session["username"];
            lblcustID.Text = (string)Session["customerid"];
        }
    }
}