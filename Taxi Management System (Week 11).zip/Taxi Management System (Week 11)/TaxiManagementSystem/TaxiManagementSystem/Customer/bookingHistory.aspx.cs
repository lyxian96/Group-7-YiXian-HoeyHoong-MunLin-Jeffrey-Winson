﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BookingReservation
{
    public partial class bookingHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtuserName.Text = (string)Session["username"];


            SqlConnection connSearch;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            connSearch = new SqlConnection(connStr);
            connSearch.Open();

            string searchStr;
            SqlCommand cmdsearch;


            searchStr = "Select CustomerID From Customer Where CustomerUsername='" + txtuserName.Text + "'";
            cmdsearch = new SqlCommand(searchStr, connSearch);

            SqlDataReader dtr;
            dtr = cmdsearch.ExecuteReader();

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    lblCustID.Text = dtr["CustomerID"].ToString();


                }




            }
        }
    }
}