﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Text;

namespace BookingReservation
{
    public partial class bookingReservePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtDate.Text = DateTime.Now.ToString("MM/dd/yyyy");
            txtCurrentTime.Text = DateTime.Now.ToString("HH:mm:ss");
            txtDay.Text = "(" + DateTime.Now.DayOfWeek.ToString() + ")";

            custName.Text = (string)Session["username"];
            txtcustID.Text = (string)Session["customerid"];

            string bookingID = getNewBookingID();
            txtBookingID.Text = bookingID;

            txtFavID.Text = getNewFavID();
            
           
        }

        private string getNewBookingID()
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            conn.Open();

            SqlCommand cmdID = new SqlCommand("Select BookingID From Booking Order By BookingID", conn);

            SqlDataReader dtr = cmdID.ExecuteReader();

            string lastID = "";

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    lastID = dtr["BookingID"].ToString();
                }
            }

            char[] IDarr = lastID.ToCharArray();

            IDarr[4]++;
            if (IDarr[4] == ':')
            {
                IDarr[3]++;
                IDarr[4] = '0';
            }
            if (IDarr[3] == ':')
            {
                IDarr[2]++;
                IDarr[3] = '0';
            }
            if (IDarr[2] == ':')
            {
                IDarr[1]++;
                IDarr[2] = '0';
            }

            string newBookingID = new String(IDarr);

            return newBookingID;
        }

        private string getNewFavID()
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            conn.Open();

            SqlCommand cmdID = new SqlCommand("Select FavID From FavDestination Order By FavID", conn);

            SqlDataReader dtr = cmdID.ExecuteReader();

            string lastID = "";

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    lastID = dtr["FavID"].ToString();
                }
            }

            char[] IDarr = lastID.ToCharArray();

            IDarr[4]++;
            if (IDarr[4] == ':')
            {
                IDarr[3]++;
                IDarr[4] = '0';
            }
            if (IDarr[3] == ':')
            {
                IDarr[2]++;
                IDarr[3] = '0';
            }
            if (IDarr[2] == ':')
            {
                IDarr[1]++;
                IDarr[2] = '0';
            }

            string newFavID = new String(IDarr);

            return newFavID;
        }

        

        protected void calenderSelect_SelectionChanged(object sender, EventArgs e)
        {
            if (calenderSelect.SelectedDate < DateTime.Today)
            {
                txtCalDate.Text = "";
                TextBox1.Text = "";
            }
        

            else
            {
                txtCalDate.Text = calenderSelect.SelectedDate.ToShortDateString();
            }


            string dayofWeek = calenderSelect.SelectedDate.DayOfWeek.ToString();

            string day = TextBox1.Text = dayofWeek;

            lblAddedStatus.Text = "";
            lblChooseTaxi.Text = "";
            GridView1.Visible = false;
            lblDName.Visible = false;
            lblDCont.Visible = false;
            lblDriverCont.Text = "";
            lblDriverName.Text = "";
            lblFavLoc.Text = "";
            


           

        }

        protected void calenderSelect_DayRender(object sender, DayRenderEventArgs e)
        {
            DateTime pastday = e.Day.Date;
            DateTime date = DateTime.Now;
            int year = date.Year;
            int month = date.Month;
            int day = date.Day;
            DateTime today = new DateTime(year, month, day);
            if (pastday.CompareTo(today) < 0)
            {
                e.Cell.BackColor = System.Drawing.Color.Gray;
                e.Day.IsSelectable = false;
            }


        }




        protected void checkBtn_Click(object sender, EventArgs e)
        {

            string currTime = txtCurrentTime.Text;
            string selectedTime = ddlSelTime.SelectedItem.ToString();

            TimeSpan tstwohrs = TimeSpan.Parse("02:00:00");
            


            string newDateTime = txtCalDate.Text +" "+ ddlSelTime.SelectedItem.ToString();

            DateTime dateandtime = DateTime.Parse(newDateTime);


            if (dateandtime > DateTime.Now)
            {


                if ((dateandtime - DateTime.Now) > tstwohrs)
                {

                    SqlConnection sqlConn;
                    string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
                    sqlConn = new SqlConnection(connStr);
                    sqlConn.Open();
                  

                    string searchStr;
                    SqlCommand cmdsearch;

                    searchStr = "SELECT TaxiPlateNo From Driver WHERE DriverStatus = 'Available'";
                    cmdsearch = new SqlCommand(searchStr, sqlConn);

                    SqlDataReader dtr;
                    dtr = cmdsearch.ExecuteReader();

                    if (dtr.HasRows)
                    {
                        while (dtr.Read())
                        {
                            lblAddedStatus.Text = "Available!";
                            GridView1.Visible = true;
                            lblChooseTaxi.Visible = true;
                
                        }

                    }
                    else
                    {
                        lblAddedStatus.Text = "No available Taxi left";
                    }



                    sqlConn.Close(); 



                }
                else
                {
                    lblAddedStatus.Text = "Taxi Unavailable!";
                }


            }
            else
            {
                lblAddedStatus.Text = "Taxi Unavailable!";
            }


            
        }



        protected void btnBook_Click(object sender, EventArgs e)
        {


            Session["bookingdate"] = txtCalDate.Text;
            Session["bookingtime"] = ddlSelTime.Text;
            Session["bookingid"] = txtBookingID.Text;
            Session["driverid"] = lblDriverID.Text;
            Session["custid"] = txtcustID.Text;
            Session["routeid"] = txtRouteID.Text;



            SqlConnection sqlConn;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your booking has been made!')", true);

            SqlConnection connSearch;
            string connStr2 = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            connSearch = new SqlConnection(connStr2);
            connSearch.Open();

            string searchStr;
            SqlCommand cmdsearch;

            searchStr = "Select FavDestination.FavDestination From FavDestination WHERE CustomerID = '" + txtcustID.Text + "' AND FavDestination = '" + GridView3.SelectedRow.Cells[1].Text+"'";
            cmdsearch = new SqlCommand(searchStr, connSearch);

            SqlDataReader dtr;
            dtr = cmdsearch.ExecuteReader();

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    ImageButton1.Visible = true;
                }

            }
            else
            {
                lblFavLoc.Text = GridView3.SelectedRow.Cells[1].Text;
                btnSaveLoc.Visible = true;
                ImageButton1.Visible = true;
            }



            sqlConn.Close(); 
            
        }

        protected void btnSaveLoc_Click(object sender, EventArgs e)
        {
            
            SqlConnection sqlConn;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            sqlConn = new SqlConnection(connStr);
            sqlConn.Open();

            DateTime dtAdded = Convert.ToDateTime(txtCurrentTime.Text);

            SqlCommand cmdAdd;
            string strAdd = "Insert into FavDestination(FavID, AddedDate, FavDestination, CustomerID) Values (@FavID, @AddedDate, @FavDestination, @CustomerID)";
            cmdAdd = new SqlCommand(strAdd, sqlConn);

            cmdAdd.Parameters.AddWithValue("@FavID", txtFavID.Text);
            cmdAdd.Parameters.AddWithValue("@AddedDate", dtAdded);
            cmdAdd.Parameters.AddWithValue("@FavDestination", GridView3.SelectedRow.Cells[1].Text);
            cmdAdd.Parameters.AddWithValue("@CustomerID", txtcustID.Text);


            int n = cmdAdd.ExecuteNonQuery();
            if (n > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your favourite destination has been added successfully')", true);
                ImageButton1.Visible = true;
            }
            else
            {
            
            }

            sqlConn.Close();
        }


        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string dtTime = GridView1.SelectedRow.Cells[1].Text;

            dtTime = ddlSelTime.SelectedItem.ToString();

            lblAddedStatus.Text = "";
            lblChooseTaxi.Text = "";
            GridView1.Visible = false;
            lblDName.Visible = false;
            lblDCont.Visible = false;
            lblDriverCont.Text = "";
            lblDriverName.Text = "";
            lblFavLoc.Text = "";


        }

        protected void GridView2_SelectedIndexChanged1(object sender, EventArgs e)
        {
            txtPickupAdd.Text = GridView2.SelectedRow.Cells[1].Text;
       //     txtPickupAdd.Visible = true;

            lblAddedStatus.Text = "";
            lblChooseTaxi.Text = "";
            GridView1.Visible = false;
            lblDName.Visible = false;
            lblDCont.Visible = false;
            lblDriverCont.Text = "";
            lblDriverName.Text = "";
            lblFavLoc.Text = "";
        }

        protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDestination.Text = GridView3.SelectedRow.Cells[1].Text;
       //     txtDestination.Visible = true;

            SqlConnection connSearch;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            connSearch = new SqlConnection(connStr);
            connSearch.Open();

            string searchStr;
            SqlCommand cmdsearch;

            string pickupAdd = txtPickupAdd.Text;
            string dest = txtDestination.Text;
            


            searchStr = "Select RouteID From Route Where PickUpAddress='" + pickupAdd + "' AND Destination ='"+ dest + "'";
            cmdsearch = new SqlCommand(searchStr, connSearch);

            SqlDataReader dtr;
            dtr = cmdsearch.ExecuteReader();

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    txtRouteID.Text = dtr["RouteID"].ToString();
                    GridView5.Visible = false;
                }




            }
            lblAddedStatus.Text = "";
            lblChooseTaxi.Text = "";
            GridView1.Visible = false;
            lblDName.Visible = false;
            lblDCont.Visible = false;
            lblDriverCont.Text = "";
            lblDriverName.Text = "";
            lblFavLoc.Text = "";

        }

        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {
            
            SqlConnection connSearch;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            connSearch = new SqlConnection(connStr);
            connSearch.Open();

            string searchStr;
            SqlCommand cmdsearch;



            string plateNo = GridView1.SelectedRow.Cells[1].Text;

            searchStr = "Select DriverID, DriverName, DriverContactNo From Driver Where TaxiPlateNo='" + plateNo + "'";
            cmdsearch = new SqlCommand(searchStr, connSearch);

            SqlDataReader dtr;
            dtr = cmdsearch.ExecuteReader();

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    lblDriverName.Text = dtr["DriverName"].ToString();
                    lblDName.Visible = true;
                    lblDriverName.Visible = true;
                    lblDriverCont.Text = dtr["DriverContactNo"].ToString();
                    lblDCont.Visible = true;
                    lblDriverCont.Visible = true;
                    lblDriverID.Text = dtr["DriverID"].ToString();
                    btnBook.Visible = true;
                }
            }
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rdbDestChoice.SelectedValue.Equals("DefaultDest"))
            {
                GridView2.Visible = true;
                GridView3.Visible = true;
                GridView4.Visible = false;
                GridView5.Visible = false;
                txtRouteID.Text = "";
            }
            if (rdbDestChoice.SelectedValue.Equals("FavouriteDest"))
            {
                GridView2.Visible = false;
                GridView3.Visible = false;
                GridView4.Visible = true;
                GridView5.Visible = false;
                txtRouteID.Text = "";
            }




        }

        protected void GridView4_SelectedIndexChanged(object sender, EventArgs e)
        {
            string favDest = GridView4.SelectedRow.Cells[1].Text;
            txtDestination.Text = favDest;
            GridView5.Visible = true;
         //   txtDestination.Visible = true;

            lblAddedStatus.Text = "";
            lblChooseTaxi.Text = "";
            GridView1.Visible = false;
            lblDName.Visible = false;
            lblDCont.Visible = false;
            lblDriverCont.Text = "";
            lblDriverName.Text = "";
            lblFavLoc.Text = "";


        }

        protected void GridView5_SelectedIndexChanged(object sender, EventArgs e)
        {
            string pickupAdd = GridView5.SelectedRow.Cells[1].Text;
            txtPickupAdd.Text = pickupAdd;
         //   txtPickupAdd.Visible = true;

            SqlConnection connSearch;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            connSearch = new SqlConnection(connStr);
            connSearch.Open();

            string searchStr;
            SqlCommand cmdsearch;
            string dest = txtDestination.Text;



            searchStr = "Select RouteID From Route Where PickUpAddress='" + pickupAdd + "' AND Destination ='" + dest + "'";
            cmdsearch = new SqlCommand(searchStr, connSearch);

            SqlDataReader dtr;
            dtr = cmdsearch.ExecuteReader();

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    txtRouteID.Text = dtr["RouteID"].ToString();
                }




            }

            lblAddedStatus.Text = "";
            lblChooseTaxi.Text = "";
            GridView1.Visible = false;
            lblDName.Visible = false;
            lblDCont.Visible = false;
            lblDriverCont.Text = "";
            lblDriverName.Text = "";
            lblFavLoc.Text = "";



        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            conn.Open();

            SqlCommand cmd = new SqlCommand("Select EstimatedCharges From Route Where RouteID = @routeid", conn);
            cmd.Parameters.AddWithValue("@routeid", Session["routeid"].ToString());

            Session["totalcharges"] = cmd.ExecuteScalar();
            conn.Close();

            string business = "JBES66T3A8HQ6";
            string itemName = "Taxi Fare";
            string itemAmount = Session["totalcharges"].ToString();
            string currencyCode = "MYR";
            string returnURL = "http://localhost:50631/Customer/PaymentSuccessful.aspx";
            string cancelURL = "http://localhost:50631/Customer/bookingReservePage.aspx";

            StringBuilder ppHref = new StringBuilder();

            ppHref.Append("https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_xclick");
            ppHref.Append("&business=" + business);
            ppHref.Append("&item_name=" + itemName);
            ppHref.Append("&amount=" + itemAmount);
            ppHref.Append("&currency_code=" + currencyCode);
            ppHref.Append("&return=" + returnURL);
            ppHref.Append("&cancel_return=" + cancelURL);
            ppHref.Append("&no_shipping=1");
            ppHref.Append("&no_note=1");

            Response.Redirect(ppHref.ToString(), true);
        }





        }





    }
