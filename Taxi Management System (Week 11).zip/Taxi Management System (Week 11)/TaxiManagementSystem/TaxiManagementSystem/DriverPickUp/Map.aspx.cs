﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace RouteMap
{
    public partial class Map : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //get the parameters passed by PickUpViewSchedule.aspx
            String pickUp = Request.QueryString["pickUp"];
            String destination = Request.QueryString["destination"];

            //assign to label
            lblFrom.Text = pickUp;
            lblTo.Text = destination;

            //retrieve coordinate from Route database
            SqlConnection conn;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            conn = new SqlConnection(connStr);
            conn.Open();

            string strSelect = "Select * from Route where PickUpAddress=@PickUpAddress AND Destination=@Destination";

            SqlCommand cmdSelect = new SqlCommand(strSelect, conn);
            cmdSelect.Parameters.AddWithValue("@PickUpAddress", pickUp);
            cmdSelect.Parameters.AddWithValue("@Destination", destination);

            SqlDataReader dtr = cmdSelect.ExecuteReader();

            if (dtr.HasRows)
            {
                dtr.Read();
                //assign to coordinate textbox
                start.Text = dtr["PickUpCoordinate"].ToString();
                end.Text = dtr["DestinationCoordinate"].ToString();
            }
            dtr.Close();
            conn.Close();
        }

        protected void btnComplete_Click(object sender, EventArgs e)
        {
            //update pickUp ArrivalTime & PickUpStatus
            String bookingID = Request.QueryString["bookingID"];

            SqlConnection conn;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            conn = new SqlConnection(connStr);
            conn.Open();

            string strUpdate = "Update PickUp SET ArrivalTime=@ArrivalTime, PickUpStatus=@PickUpStatus WHERE BookingID=@BookingID";
            SqlCommand cmdUpdate;
            cmdUpdate = new SqlCommand(strUpdate, conn);

            cmdUpdate.Parameters.AddWithValue("@ArrivalTime", DateTime.Now.ToString("HH:mm:ss"));
            cmdUpdate.Parameters.AddWithValue("@PickUpStatus", "Complete");
            cmdUpdate.Parameters.AddWithValue("@BookingID", bookingID);

            int intUpdateStatus = cmdUpdate.ExecuteNonQuery();

            string strUpdateDriver = "Update Driver SET DriverStatus=@DriverStatus WHERE DriverUsername=@DriverUsername";
            SqlCommand cmdUpdateDriver;
            cmdUpdateDriver = new SqlCommand(strUpdateDriver, conn);

            cmdUpdateDriver.Parameters.AddWithValue("@DriverStatus", "Available");
            cmdUpdateDriver.Parameters.AddWithValue("@DriverUsername", Session["username"].ToString());

            int intUpdateDriverStatus = cmdUpdateDriver.ExecuteNonQuery();

            conn.Close();

            //prompt schedule completed message
            string message = "Schedule is completed.";
            string url = "PickUpViewSchedule.aspx";
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "');";
            script += "window.location = '";
            script += url;
            script += "'; }";
            ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("PickUpViewSchedule.aspx");
        }
    }
}