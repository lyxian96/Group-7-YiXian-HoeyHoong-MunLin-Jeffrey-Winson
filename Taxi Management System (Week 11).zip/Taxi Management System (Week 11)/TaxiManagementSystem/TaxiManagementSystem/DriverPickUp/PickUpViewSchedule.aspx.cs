﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;

namespace RouteMap
{
    public partial class PickUpViewSchedule : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGo_Click(object sender, EventArgs e)
        {
            //get row data
            GridViewRow row = GridViewSchedule.SelectedRow;

            String lastPickUpID = "";
            Boolean bookingIDExist = true;

            SqlConnection conn;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            conn = new SqlConnection(connStr);
            conn.Open();

            //find whether bookingID is existed
            string strFind = "Select * from PickUp where BookingID=@BookingID";
            SqlCommand cmdFind = new SqlCommand(strFind, conn);
            cmdFind.Parameters.AddWithValue("@BookingID", row.Cells[1].Text);
            SqlDataReader dtrFind = cmdFind.ExecuteReader();

            if (!dtrFind.HasRows) //check whether bookingID existed
            {
                bookingIDExist = false;
            }
            dtrFind.Close();

            if (bookingIDExist == false)
            { //if bookingID not found

                string strSelect = "Select * from PickUp";
                SqlCommand cmdSelect = new SqlCommand(strSelect, conn);
                SqlDataReader dtr = cmdSelect.ExecuteReader();

                if (dtr.HasRows)
                {
                    //get last ID
                    while (dtr.Read())
                    {
                        lastPickUpID = dtr["PickUpID"].ToString();
                    }
                    dtr.Close();
                    //then create new pickUp record
                    string strInsert;
                    SqlCommand cmdInsert;
                    strInsert = "Insert Into PickUp (PickUpID, DepartureTime, ArrivalTime, PickUpStatus, BookingID) Values (@PickUpID, @DepartureTime, @ArrivalTime, @PickUpStatus, @BookingID)";
                    cmdInsert = new SqlCommand(strInsert, conn);

                    cmdInsert.Parameters.AddWithValue("@PickUpID", getNewID(lastPickUpID));
                    cmdInsert.Parameters.AddWithValue("@DepartureTime", DateTime.Now.ToString("HH:mm:ss"));
                    cmdInsert.Parameters.AddWithValue("@ArrivalTime", DateTime.Now.ToString("HH:mm:ss"));
                    cmdInsert.Parameters.AddWithValue("@PickUpStatus", "Depart");
                    cmdInsert.Parameters.AddWithValue("@BookingID", row.Cells[1].Text);

                    int n = cmdInsert.ExecuteNonQuery();
                }
            }
            conn.Close();

            //get pickUpAddress and destionationAddress
            //redirect to Map.aspx
            Response.Redirect("Map.aspx?bookingID=" + row.Cells[1].Text + "&pickUp=" + row.Cells[4].Text + "&destination=" + row.Cells[5].Text);
        }

        public string getNewID(String oldID)
        {
            String newID = oldID;
            newID = "" + newID[0] + newID[1] + newID[2] + newID[3] + (char)((int)newID[4] + 1);

            if (newID[4] == ':')
            {
                newID = "" + newID[0] + newID[1] + newID[2] + (char)((int)newID[3] + 1) + "0";
            }
            if (newID[3] == ':')
            {
                newID = "" + newID[0] + newID[1] + (char)((int)newID[2] + 1) + "00";
            }
            if (newID[2] == ':')
            {
                newID = "" + newID[0] + (char)((int)newID[1] + 1) + "000";
            }

            String finalNewID = newID;

            return finalNewID;
        }


        protected void SendMail()
        {
            string receiveremail = "";
            string customerid = "";
            GridViewRow row = GridViewSchedule.SelectedRow;
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            conn.Open();

            //customer username
            SqlCommand cmd1 = new SqlCommand("SELECT CustomerID FROM Booking WHERE BookingID = @bookid", conn);
            cmd1.Parameters.AddWithValue("@bookid", row.Cells[1].Text);
            SqlDataReader dtr1 = cmd1.ExecuteReader();
            while (dtr1.Read())
            {
                // get the results of each column
                customerid = (string)dtr1["CustomerID"];
            }

            conn.Close();

            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT CustomerEmail FROM Customer WHERE CustomerID = @id", conn);
            cmd.Parameters.AddWithValue("@id", customerid);


            SqlDataReader dtr = cmd.ExecuteReader();

            while (dtr.Read())
            {
                // get the results of each column
                receiveremail = (string)dtr["CustomerEmail"];
            }


            // Gmail Address from where you send the mail
            var fromAddress = "jeffreylee699jl@gmail.com";
            // any address where the email will be sending
            var toAddress = receiveremail;
            //Password of your gmail address
            const string fromPassword = "k123456k";
            // Passing the values and make a email formate to display
            string subject = "EzCab Notification";
            string body = "Hi, here is a friendly reminder.\nYour driver is on the way to your location!\n\nP.S:Will be arrive around 15minutes.\n\n\nPlease do not hesitate to email us your feedback, your feedback will make us better!";
            // smtp settings
            var smtp = new System.Net.Mail.SmtpClient();
            {
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                smtp.Credentials = new NetworkCredential(fromAddress, fromPassword);
                smtp.Timeout = 20000;
            }
            // Passing values to smtp object
            smtp.Send(fromAddress, toAddress, subject, body);

            conn.Close();


            //Add record to Notification Table
            conn.Open();
            //Insert statement and Sql Insert Object
            string strInsert;
            SqlCommand cmdInsert;
            strInsert = "Insert Into Notification (DateCreated, NotificationStatus, BookingID) Values ( @date, @status, @bookingID)";

            cmdInsert = new SqlCommand(strInsert, conn);

            cmdInsert.Parameters.AddWithValue("@date", DateTime.Now);
            cmdInsert.Parameters.AddWithValue("@status", "Sent");
            cmdInsert.Parameters.AddWithValue("@bookingID", row.Cells[1].Text);

            int n = cmdInsert.ExecuteNonQuery();

            conn.Close();

        }

        protected void btnSendNotification_Click(object sender, EventArgs e)
        {
            //get row data
            GridViewRow row = GridViewSchedule.SelectedRow;
            String bookingID = row.Cells[1].Text;

            //here on button click what will done 
            try
            {
                SendMail();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your email have been sent.')", true);

            }
            catch (Exception)
            {
                //Update notification status to Failed
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
                conn.Open();
                string strInsert;
                SqlCommand cmdInsert;
                strInsert = "Insert Into Notification (DateCreated, NotificationStatus, BookingID) Values ( @date, @status, @bookingID)";

                cmdInsert = new SqlCommand(strInsert, conn);

                cmdInsert.Parameters.AddWithValue("@date", DateTime.Now);
                cmdInsert.Parameters.AddWithValue("@status", "Failed");
                cmdInsert.Parameters.AddWithValue("@bookingID", row.Cells[1].Text);

                cmdInsert.ExecuteNonQuery();

                conn.Close();

                //here show a message if fail to send an email
                string message = "Your email failed to send due to unstable network.";
                string url = "PickUpViewSchedule.aspx";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += url;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
            }
        }









    }
}