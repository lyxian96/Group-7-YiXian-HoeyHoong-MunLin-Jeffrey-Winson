﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TaxiManagementSystem.Register
{
    public partial class AddDriver : System.Web.UI.Page
    {

        protected void btnReg_Click(object sender, EventArgs e)
        {
            int count = 0; //form validation
            string phone = txtNum.Text;
            if (txtName.Text == "" || txtIC.Text == "" || txtAdd.Text == "" || txtNum.Text == "" || txtUser.Text == "" || txtPass.Text == "" || txtEadd.Text == "")
            {
                Response.Write("<script language='javascript'>window.alert('Please fill in all the form !');</script>");
            }
            //else if () // number validation
            //{
            //  lblMessage.Text = "[Please fill in NUMBERS ONLY !]";
            //}

            else //check redundancy
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
                conn.Open();


                SqlCommand cmd = new SqlCommand("SELECT CustomerUsername FROM Customer", conn);

                SqlDataReader dtr = cmd.ExecuteReader();

                if (dtr.HasRows)
                {
                    while (dtr.Read())
                    {
                        if (dtr["CustomerUsername"].ToString().Equals(txtUser.Text))
                        {
                            count = 1;
                        }
                        else
                        {
                            count = 0;
                        }
                    }
                    dtr.Close();
                }
                conn.Close();

                if (count == 1)
                {
                    Response.Write("<script language='javascript'>window.alert('Username already exist !');</script>");
                }
                else
                {
                    // customerID declaration

                    String lastCustomerID = "";

                    conn.Open();


                    string strSelect = "Select * from Customer";
                    SqlCommand cmdSelect = new SqlCommand(strSelect, conn);
                    SqlDataReader dtr1 = cmdSelect.ExecuteReader();


                    while (dtr1.Read())
                    {
                        lastCustomerID = dtr1["CustomerID"].ToString();
                    }
                    dtr1.Close();

                    string strInsert; //add
                    SqlCommand cmdInsert;
                    strInsert = "Insert Into Customer (CustomerID, CustomerName, CustomerIC, CustomerAdress, CustomerContactNo, CustomerUsername, CustomerPassword, CustomerEmail ) Values (@ID, @name, @IC, @address, @contactno, @username, @password, @email)";

                    cmdInsert = new SqlCommand(strInsert, conn);

                    cmdInsert.Parameters.AddWithValue("@ID", getNewID(lastCustomerID));
                    cmdInsert.Parameters.AddWithValue("@name", txtName.Text);
                    cmdInsert.Parameters.AddWithValue("@IC", txtIC.Text);
                    cmdInsert.Parameters.AddWithValue("@address", txtAdd.Text);
                    cmdInsert.Parameters.AddWithValue("@contactno", txtNum.Text);
                    cmdInsert.Parameters.AddWithValue("@username", txtUser.Text);
                    cmdInsert.Parameters.AddWithValue("@password", txtPass.Text);
                    cmdInsert.Parameters.AddWithValue("@email", txtEadd.Text);

                    int n = cmdInsert.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("<script language='javascript'>window.alert('Congratulation');</script>");
                    Response.Redirect("/Home.aspx");

                }
            }
        }

        public string getNewID(String oldID)
        {
            String newID = oldID;
            newID = "" + newID[0] + newID[1] + newID[2] + newID[3] + newID[4] + (char)((int)newID[5] + 1);

            if (newID[5] == ':')
            {
                newID = "" + newID[0] + newID[1] + newID[2] + newID[3] + (char)((int)newID[4] + 1) + "0";
            }
            if (newID[4] == ':')
            {
                newID = "" + newID[0] + newID[1] + newID[2] + (char)((int)newID[3] + 1) + "00";
            }
            if (newID[3] == ':')
            {
                newID = "" + newID[0] + newID[1] + (char)((int)newID[2] + 1) + "000";
            }
            if (newID[2] == ':')
            {
                newID = "" + newID[0] + (char)((int)newID[1] + 1) + "0000";
            }

            String finalNewID = newID;

            return finalNewID;
        }
    }
}
