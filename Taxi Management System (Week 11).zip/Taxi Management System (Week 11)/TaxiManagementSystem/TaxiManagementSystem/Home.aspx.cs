﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


namespace TaxiManagementSystem
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" || txtPassword.Text == "")
            {
                lblMessage.Text = "[Both Username and Password must be filled.]";
            }
            else if (txtUsername.Text == "manager" && txtPassword.Text == "123456")
            {
                Session.Remove("customerid");
                Session.Remove("username");
                Session["username"] = "manager";
                Response.Redirect("/Manager/Report.aspx"); //redirect to driver maintenance page
            }
            else
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
                conn.Open();

                //customer username
                SqlCommand cmd = new SqlCommand("SELECT * FROM Customer WHERE CustomerUsername = @username AND CustomerPassword = @password", conn);
                cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@password", txtPassword.Text);

                SqlDataReader dtr = cmd.ExecuteReader();

                if (dtr.HasRows)
                {
                    while (dtr.Read())
                    {
                        Session.Remove("customerid");
                        Session.Remove("username");
                        Session["customerid"] = dtr["CustomerID"].ToString();
                        Session["username"] = dtr["CustomerUsername"].ToString();
                        Response.Redirect("/Customer/bookingReservePage.aspx"); //redirect to booking page
                    }
                }
                //Driver username
                else
                {
                    dtr.Close(); //close customer SqlDataReader

                    SqlCommand driverCmd = new SqlCommand("SELECT * FROM Driver WHERE DriverUsername = @username AND DriverPassword = @password", conn);
                    driverCmd.Parameters.AddWithValue("@username", txtUsername.Text);
                    driverCmd.Parameters.AddWithValue("@password", txtPassword.Text);

                    SqlDataReader driverDtr = driverCmd.ExecuteReader();

                    if (driverDtr.HasRows)
                    {
                        while (driverDtr.Read())
                        {
                            Session.Remove("customerid");
                            Session.Remove("username");
                            Session["username"] = driverDtr["DriverUsername"].ToString();
                            Response.Redirect("DriverPickUp/PickUpViewSchedule.aspx"); //redirect to pickUpViewSchedule page
                        }
                        driverDtr.Close();
                    }
                    else
                    {
                        lblMessage.Text = "[Invalid Username or Password.]";
                    }
                }

                conn.Close();
                
            }
        }
    }
}