﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BookingReservation
{
    public partial class BookingMonthlyRep : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /*
           lblCustUserName.Text = (string)Session["username"];

           SqlConnection connSearch;
           string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
           connSearch = new SqlConnection(connStr);
           connSearch.Open();

           string searchStr;
           SqlCommand cmdsearch;


           searchStr = "Select CustomerID From Customer Where CustomerUsername='"+lblCustUserName.Text+"'";
           cmdsearch = new SqlCommand(searchStr, connSearch);

           SqlDataReader dtr;
           dtr = cmdsearch.ExecuteReader();

           if (dtr.HasRows)
           {
               while (dtr.Read())
               {
                   lblCustID.Text = dtr["CustomerID"].ToString();
                
                   
               }




           }
              */
         



        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Monthly Booking Report, " + DropDownList1.SelectedItem + " 2016";

            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
        }

       

        }
    }