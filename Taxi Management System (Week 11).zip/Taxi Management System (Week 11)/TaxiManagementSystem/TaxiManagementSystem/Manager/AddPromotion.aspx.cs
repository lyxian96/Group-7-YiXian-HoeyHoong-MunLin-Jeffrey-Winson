﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TaxiManagementSystem.Manager
{
    public partial class AddPromotion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void clear(object sender, EventArgs e)
        {
            calTo.SelectedDates.Clear();
            calTo.Enabled = true;
        }

        //only let manager choose today onward day in the calendar
        protected void calFrom_DayRender(object sender, DayRenderEventArgs e)
        {
            DateTime pastday = e.Day.Date;
            DateTime date = DateTime.Now;
            int year = date.Year;
            int month = date.Month;
            int day = date.Day;
            DateTime today = new DateTime(year, month, day);
            if (pastday.CompareTo(today) < 0)
            {
                e.Cell.BackColor = System.Drawing.Color.Gray;
                e.Day.IsSelectable = false;
              
            }

            
        }

        protected void calTo_DayRender(object sender, DayRenderEventArgs e)
        {
            DateTime pastday = e.Day.Date;
            DateTime date = DateTime.Now;
            int year = date.Year;
            int month = date.Month;
            int day = date.Day;
            DateTime from = calFrom.SelectedDate;
            if (pastday.CompareTo(from) < 0)
            {
                e.Cell.BackColor = System.Drawing.Color.Gray;
                e.Day.IsSelectable = false;
            }
        }

        public string getNewID(String oldID)
        {
            String newID = oldID;
            newID = "" + newID[0] + newID[1] + newID[2] + newID[3] + (char)((int)newID[4] + 1);

            if (newID[4] == ':')
            {
                newID = "" + newID[0] + newID[1] + newID[2] + (char)((int)newID[3] + 1) + "0";
            }
            if (newID[3] == ':')
            {
                newID = "" + newID[0] + newID[1] + (char)((int)newID[2] + 1) + "00";
            }
            if (newID[2] == ':')
            {
                newID = "" + newID[0] + (char)((int)newID[1] + 1) + "000";
            }

            String finalNewID = newID;

            return finalNewID;
        }


        protected void btnAddPromotion_Click(object sender, EventArgs e)
        {
            if (txtarea.InnerText == "")
            {
                string message = "You must write something in the description.";
                string url = "AddPromotion.aspx";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += url;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
            }
            else
            {
                try
                {
                    String lastPromotionID = "";
                    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
                    conn.Open();


                    string strSelect = "Select * from Promotion";
                    SqlCommand cmdSelect = new SqlCommand(strSelect, conn);
                    SqlDataReader dtr = cmdSelect.ExecuteReader();

                    //get last Promotion ID
                    while (dtr.Read())
                    {
                        lastPromotionID = dtr["PromotionID"].ToString();
                    }
                    dtr.Close();



                    //Insert statement and Sql Insert Object
                    string strInsert;
                    SqlCommand cmdInsert;
                    strInsert = "Insert Into Promotion (PromotionID, PromotionStartDate, PromotionEndDate, PromotionDescription) Values ( @id, @startdate, @enddate, @description)";

                    cmdInsert = new SqlCommand(strInsert, conn);

                    cmdInsert.Parameters.AddWithValue("@id", getNewID(lastPromotionID));
                    cmdInsert.Parameters.AddWithValue("@startdate", calFrom.SelectedDate);
                    cmdInsert.Parameters.AddWithValue("@enddate", calTo.SelectedDate);
                    string textarea = txtarea.InnerText;
                    cmdInsert.Parameters.AddWithValue("@description", textarea);

                    int n = cmdInsert.ExecuteNonQuery();

                    conn.Close();

                    //Here show a message after added a promotion and link to view promotion
                    string message = "Promotion Added.";
                    string url = "ViewPromotion.aspx";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "');";
                    script += "window.location = '";
                    script += url;
                    script += "'; }";
                    ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
                }
                catch (Exception)
                {
                    //here show a message if fail add a promotion due to date input error
                    string message = "You must select a day for both of the calendar.";
                    string url = "AddPromotion.aspx";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "');";
                    script += "window.location = '";
                    script += url;
                    script += "'; }";
                    ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
                }
            }
        }
    }
}