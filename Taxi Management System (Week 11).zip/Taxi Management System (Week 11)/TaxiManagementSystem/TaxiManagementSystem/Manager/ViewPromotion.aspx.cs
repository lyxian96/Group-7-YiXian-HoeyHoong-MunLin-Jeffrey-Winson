﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;

namespace TaxiManagementSystem.Manager
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }


        protected void SendMail()
        {
            string receiveremail = "";
            string customerid = "";
            string promotionid = "";
            string promotionstart = "";
            string promotionend = "";
            string description = "";
            GridViewRow row = GridViewPromotion.SelectedRow;
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            
            conn.Open();

            //customer username
            SqlCommand cmd1 = new SqlCommand("SELECT * FROM Promotion WHERE PromotionID = @promotionid", conn);
            cmd1.Parameters.AddWithValue("@promotionid", row.Cells[1].Text);
            SqlDataReader dtr1 = cmd1.ExecuteReader();
            while (dtr1.Read())
            {
                // get the results of each column
                promotionid = (string)dtr1["PromotionID"];
                promotionstart = (string)dtr1["PromotionStartDate"].ToString();
                promotionend = (string)dtr1["PromotionEndDate"].ToString();
                description = (string)dtr1["PromotionDescription"];
            }

            conn.Close();


            conn.Open();
            SqlCommand cmd2 = new SqlCommand("SELECT CustomerEmail FROM Customer", conn);

            SqlDataReader dtr2 = cmd2.ExecuteReader();
            while (dtr2.Read())
            {
                // get the results of each column

                receiveremail = (string)dtr2["CustomerEmail"];

                // Gmail Address from where you send the mail
                var fromAddress = "jeffreylee699jl@gmail.com";
                // any address where the email will be sending
                var toAddress = receiveremail;
                //Password of your gmail address
                const string fromPassword = "k123456k";
                // Passing the values and make a email formate to display
                string subject = "EzCab Promotion";
                string body = description + "\n\nPromotion will start on: " + promotionstart + "\nPromotion will end on: " + promotionend + "\n\n\n\n\nPS: Here is the Promotion code: " + promotionid;
                // smtp settings
                var smtp = new System.Net.Mail.SmtpClient();
                {
                    smtp.Host = "smtp.gmail.com";
                    smtp.Port = 587;
                    smtp.EnableSsl = true;
                    smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                    smtp.Credentials = new NetworkCredential(fromAddress, fromPassword);
                    smtp.Timeout = 20000;
                }
                // Passing values to smtp object
                smtp.Send(fromAddress, toAddress, subject, body);
            }
            conn.Close();



            //Add record to PromotionDetail Table
            conn.Open();

            SqlCommand cmd3 = new SqlCommand("SELECT CustomerID FROM Customer", conn);

            SqlDataReader dtr3 = cmd3.ExecuteReader();
            while (dtr3.Read())
            {
                customerid = (string)dtr3["CustomerID"];
                
                

                conn1.Open();
                //Insert statement and Sql Insert Object
                string strInsert;
                SqlCommand cmdInsert;
                strInsert = "Insert Into PromotionDetail (CustomerID, PromotionID, DateSent) Values ( @customerid, @promotionid, @date)";

                cmdInsert = new SqlCommand(strInsert, conn1);

                cmdInsert.Parameters.AddWithValue("@customerid", customerid);
                cmdInsert.Parameters.AddWithValue("@promotionid", row.Cells[1].Text);
                cmdInsert.Parameters.AddWithValue("@date", DateTime.Now);

                int n = cmdInsert.ExecuteNonQuery();

                conn1.Close();
            }
            conn.Close();
        }

       /* protected void refresh_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewPromotion.aspx");
        } */

        protected void btnSendPromotion_Click(object sender, EventArgs e)
        {
            try
            {
                SendMail();

                string message = "The Promotion has been send to all Customer.";
                string url = "ViewPromotion.aspx";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += url;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
            }
            catch (Exception)
            {
                //here show a message if fail to send an email
                string message = "Your email failed to send due to unstable network.";
                string url = "ViewPromotion.aspx";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += url;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
            }
        }

        protected void refresh_Click(object sender, GridViewDeletedEventArgs e)
        {
           
               Response.Redirect("ViewPromotion.aspx");
              //  ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('ok.')", true);
            
        }

        
    }
}