﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace BookingReservation
{
    public partial class TopCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection connSearch;
            string connStr = ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString;
            connSearch = new SqlConnection(connStr);
            connSearch.Open();

            string searchStr;
            SqlCommand cmdsearch;

            string month = DropDownList1.SelectedValue.ToString();


            searchStr = "Select Customer.CustomerName, count(Customer.CustomerName) AS c FROM Booking JOIN Customer ON Booking.CustomerID = Customer.CustomerID WHERE month(Booking.BookingDate)= " + month + "group by Customer.CustomerName order by c";
            cmdsearch = new SqlCommand(searchStr, connSearch);

            SqlDataReader dtr;
            dtr = cmdsearch.ExecuteReader();

            if (dtr.HasRows)
            {
                while (dtr.Read())
                {
                    lblTitle.Text = "Top Customer of the Month, " + DropDownList1.SelectedItem + " 2016";
                    titleTop.Text = "Top Customer of the Month: ";
                    lblTopCust.Text = dtr["CustomerName"].ToString();
                }
            }
            else
            {
                lblTopCust.Text = "";
            }

            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
        }
    }
}