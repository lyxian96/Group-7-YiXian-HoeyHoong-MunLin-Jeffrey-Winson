﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

using System.Net.Sockets;
using Microsoft.Office.Interop.Outlook;

namespace TaxiManagementSystem.Manager
{
    public partial class ViewEmail : System.Web.UI.Page
    {
        public static int i = 1;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        
        protected void btnViewEmail_OnClick(object sender, EventArgs e)
        {
            i = 1;
            btnBack.Enabled = true;
            btnNext.Enabled = true;

            Microsoft.Office.Interop.Outlook.Application myApp = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook.NameSpace mapiNameSpace = myApp.GetNamespace("MAPI");
            Microsoft.Office.Interop.Outlook.MAPIFolder myInbox = mapiNameSpace.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderInbox);
            if (myInbox.Items.Count > 0)
            {
                // Grab the Subject
                txtSubject.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Subject;
                //Grab the Attachment Name
                if (((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Attachments.Count > 0)
                {
                    txtAttachmentName.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Attachments[i].FileName;
                }
                else
                {
                    txtAttachmentName.Text = "No Attachment";
                }
                // Grab the Body
                txtbody.InnerText = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Body;
                // Sender Name
                txtSenderName.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).SenderName;
                // Sender Email
                txtSenderEmail.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).SenderEmailAddress;
                // Creation date
                txtCreatedDate.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).CreationTime.ToString();
            }
            else
            {
                //here show a message if no email in the inbox
                string message = "There are no emails in your Inbox.";
                string url = "ViewEmail.aspx";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += url;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
            }
            
        }


        protected void btnNext_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Outlook.Application myApp = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook.NameSpace mapiNameSpace = myApp.GetNamespace("MAPI");
            Microsoft.Office.Interop.Outlook.MAPIFolder myInbox = mapiNameSpace.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderInbox);

            if (i < myInbox.Items.Count)
            {
                i = i + 1;

                if (myInbox.Items.Count > 0)
                {
                    // Grab the Subject
                    txtSubject.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Subject;
                    //Grab the Attachment Name
                    if (((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Attachments.Count > 0)
                    {
                        txtAttachmentName.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Attachments[i].FileName;
                    }
                    else
                    {
                        txtAttachmentName.Text = "No Attachment";
                    }
                    // Grab the Body
                    txtbody.InnerText = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Body;
                    // Sender Name
                    txtSenderName.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).SenderName;
                    // Sender Email
                    txtSenderEmail.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).SenderEmailAddress;
                    // Creation date
                    txtCreatedDate.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).CreationTime.ToString();
                }
                else
                {
                    //here show a message if no email in the inbox
                    string message = "There are no emails in your Inbox.";
                    string url = "ViewEmail.aspx";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "');";
                    script += "window.location = '";
                    script += url;
                    script += "'; }";
                    ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('This is the last email, you cannot next already.')", true);
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Outlook.Application myApp = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook.NameSpace mapiNameSpace = myApp.GetNamespace("MAPI");
            Microsoft.Office.Interop.Outlook.MAPIFolder myInbox = mapiNameSpace.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderInbox);

            if (i > 1)
            {
                i = i - 1;
                if (myInbox.Items.Count > 0)
                {
                    // Grab the Subject
                    txtSubject.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Subject;
                    //Grab the Attachment Name
                    if (((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Attachments.Count > 0)
                    {
                        txtAttachmentName.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Attachments[i].FileName;
                    }
                    else
                    {
                        txtAttachmentName.Text = "No Attachment";
                    }
                    // Grab the Body
                    txtbody.InnerText = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).Body;
                    // Sender Name
                    txtSenderName.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).SenderName;
                    // Sender Email
                    txtSenderEmail.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).SenderEmailAddress;
                    // Creation date
                    txtCreatedDate.Text = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[i]).CreationTime.ToString();
                }
                else
                {
                    //here show a message if no email in the inbox
                    string message = "There are no emails in your Inbox.";
                    string url = "ViewEmail.aspx";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "');";
                    script += "window.location = '";
                    script += url;
                    script += "'; }";
                    ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
                }

            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('This is the first email, you cannot previous already.')", true);
            }

        }

    
    }
}