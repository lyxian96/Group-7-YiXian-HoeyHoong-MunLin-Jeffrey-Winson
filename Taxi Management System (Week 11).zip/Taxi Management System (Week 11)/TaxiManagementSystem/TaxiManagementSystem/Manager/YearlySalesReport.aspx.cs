﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TaxiManagementSystem.Manager
{
    public partial class YearlySalesReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Yearly Sales Report " + DropDownList1.SelectedValue;

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EzCabConn"].ConnectionString);
            conn.Open();

            SqlCommand cmd = new SqlCommand("Select Sum(TotalCharges) As GrandTotal From Payment Where Year(PaymentDate) = @year", conn);
            cmd.Parameters.AddWithValue("@year", DropDownList1.SelectedValue);

            Session.Remove("grandtotal");
            Session["grandtotal"] = cmd.ExecuteScalar().ToString();

            conn.Close();

            Repeater1.DataSource = SqlDataSource1;
            Repeater1.DataBind();
        }
    }
}